package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App extends JFrame {

    private String operator = ""; 
    private int value_01;
    private int value_02;
    private boolean newInput = true; 

    public App(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panelButton = new JPanel(new GridLayout(0,4)); 
        JTextField textFieldScreen = new JFormattedTextField("0"); 
        textFieldScreen.setHorizontalAlignment(JTextField.RIGHT);
        textFieldScreen.setEditable(false);

        // ---------------- 9 ----------------
        JButton button_09 = new JButton("9");
        button_09.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("9");
                else
                    textFieldScreen.setText(value + "9");
                newInput = false;
            }
        });
        panelButton.add(button_09);


        // ---------------- 8 ----------------
        JButton button_08 = new JButton("8");
        button_08.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("8");
                else
                    textFieldScreen.setText(value + "8");
                newInput = false;
            }
        });
        panelButton.add(button_08);


        // ---------------- 7 ----------------
        JButton button_07 = new JButton("7");
        button_07.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("7");
                else
                    textFieldScreen.setText(value + "7");
                newInput = false;
            }
        });
        panelButton.add(button_07);


        // ---------------- "/" ----------------
        JButton button_dziel = new JButton("/");
        button_dziel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                value_01 = Integer.parseInt(textFieldScreen.getText());
                operator = "/";
                newInput = true;
            }
        });
        panelButton.add(button_dziel);



        // ---------------- 6 ----------------
        JButton button_06 = new JButton("6");
        button_06.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("6");
                else
                    textFieldScreen.setText(value + "6");
                newInput = false;
            }
        });
        panelButton.add(button_06);


        // ---------------- 5 ----------------
        JButton button_05 = new JButton("5");
        button_05.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("5");
                else
                    textFieldScreen.setText(value + "5");
                newInput = false;
            }
        });
        panelButton.add(button_05);


        // ---------------- 4 ----------------
        JButton button_04 = new JButton("4");
        button_04.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("4");
                else
                    textFieldScreen.setText(value + "4");
                newInput = false;
            }
        });
        panelButton.add(button_04);


        // ---------------- "*" ----------------
        JButton button_mno = new JButton("*");
        button_mno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                value_01 = Integer.parseInt(textFieldScreen.getText());
                operator = "*";
                newInput = true;
            }
        });
        panelButton.add(button_mno);


        // ---------------- 3 ----------------
        JButton button_03 = new JButton("3");
        button_03.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("3");
                else
                    textFieldScreen.setText(value + "3");
                newInput = false;
            }
        });
        panelButton.add(button_03);


        // ---------------- 2 ----------------
        JButton button_02 = new JButton("2");
        button_02.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("2");
                else
                    textFieldScreen.setText(value + "2");
                newInput = false;
            }
        });
        panelButton.add(button_02);


        // ---------------- 1 ----------------
        JButton button_01 = new JButton("1");
        button_01.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") == 0 || newInput)
                    textFieldScreen.setText("1");
                else
                    textFieldScreen.setText(value + "1");
                newInput = false;
            }
        });
        panelButton.add(button_01);


        // ---------------- "-" ----------------
        JButton button_minus = new JButton("-");
        button_minus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                value_01 = Integer.parseInt(textFieldScreen.getText());
                operator = "-";
                newInput = true;
            }
        });
        panelButton.add(button_minus);


        // ---------------- 0 ----------------
        JButton button_00 = new JButton("0");
        button_00.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.compareTo("0") != 0 && !newInput)
                    textFieldScreen.setText(value + "0");
                else if (newInput) {
                    textFieldScreen.setText("0");
                }
                newInput = false;
            }
        });
        panelButton.add(button_00);


        panelButton.add(new JLabel(""));
        panelButton.add(new JLabel(""));


        // ---------------- "+" ----------------
        JButton button_add = new JButton("+");
        button_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                value_01 = Integer.parseInt(textFieldScreen.getText());
                operator = "+";
                newInput = true;
            }
        });
        panelButton.add(button_add);


        // ---------------- "C" ----------------
        JButton button_clear = new JButton("C");
        button_clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textFieldScreen.setText("0");
                operator = "";
                value_01 = 0;
                value_02 = 0;
                newInput = true;
            }
        });
        panelButton.add(button_clear);


        // ---------------- "<-" ----------------
        JButton button_del = new JButton("<-");
        button_del.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = textFieldScreen.getText();
                if (value.length() > 1) {
                    textFieldScreen.setText(value.substring(0, value.length() - 1));
                } else {
                    textFieldScreen.setText("0");
                }
            }
        });
        panelButton.add(button_del);


        panelButton.add(new JLabel(""));


        // ---------------- "=" ----------------
        JButton button_eq = new JButton("=");
        button_eq.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                value_02 = Integer.parseInt(textFieldScreen.getText());
                int result = 0;

                switch (operator) {
                    case "+":
                        result = value_01 + value_02;
                        break;
                    case "-":
                        result = value_01 - value_02;
                        break;
                    case "*":
                        result = value_01 * value_02;
                        break;
                    case "/":
                        if (value_02 != 0) {
                            result = value_01 / value_02;
                        } else {
                            JOptionPane.showMessageDialog(null, "Nie można dzielić przez 0!");
                            result = 0;
                        }
                        break;
                }

                textFieldScreen.setText(String.valueOf(result));
                operator = "";
                newInput = true;
            }
        });
        panelButton.add(button_eq);


        setLayout(new BorderLayout());
        add(textFieldScreen,BorderLayout.NORTH);
        add(panelButton,BorderLayout.CENTER);

        pack();
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App().setVisible(true);
            }
        });
    }
}


