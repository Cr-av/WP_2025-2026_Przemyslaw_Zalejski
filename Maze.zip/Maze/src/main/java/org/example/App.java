package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Hello world!
 *
 */
public class App extends JFrame
{
    private JMyPanel panel = new JMyPanel(); 
    private Image image;

    public App() {
        setSize(400, 300);   // rozmiar okna aplikacji
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // sposób zamykania aplikacji - standardowy
        setLayout(new BorderLayout());  // ustawienie menadżera rozkładu
        add(panel, BorderLayout.CENTER);
        JPanel panelMenu = new JPanel(new GridLayout(1, 1));
        add(panelMenu, BorderLayout.NORTH);
        JButton buttonDraw = new JButton("Draw maze");
        buttonDraw.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = 100;
                int y = 50;  // współrzędne początku labiryntu
                image = panel.getImage();   // pobieramy z panela referencję obiektu obrazu, na którym rysujemy

                if (image == null) return;  

                buildMaze(x, y);   // rysujemy labirynt
                panel.repaint();   // odrysowanie obrazu na panelu
            }
        });
        panelMenu.add(buttonDraw);
        setVisible(true);  // wyświetla okno aplikacji na ekranie
    }

    private void buildMaze(int x, int y) {

        int nr = 1;


        Wall w1 = new Wall(Directions.South); 
        w1.setX(x);
        w1.setY(y);

        Wall w2 = new Wall(Directions.East);
        w2.setX(x);
        w2.setY(y);

        Room r1 = new Room(x, y, nr++);
        r1.setSite(Directions.South, w1);
        r1.setSite(Directions.East, w2);
        r1.setSite(Directions.North, new Wall(Directions.North)); 
        r1.setSite(Directions.West, new Wall(Directions.West));   

        Room r2 = new Room(x + MapSite.Length, y, nr++);
        r2.setSite(Directions.South, new Wall(Directions.South)); 
        r2.setSite(Directions.East, new Wall(Directions.East));
        r2.setSite(Directions.North, new Wall(Directions.North)); 
        r2.setSite(Directions.West, new Wall(Directions.West));

        Room r3 = new Room(x + MapSite.Length, y + MapSite.Length, nr++);
        r3.setSite(Directions.South, new Wall(Directions.South)); 
        r3.setSite(Directions.East, new Wall(Directions.East));
        r3.setSite(Directions.North, new Wall(Directions.North)); 
        r3.setSite(Directions.West, new Wall(Directions.West));

        Room r8 = new Room(x + 3*MapSite.Length, y + MapSite.Length, nr++);
        r8.setSite(Directions.South, new Wall(Directions.South)); 
        r8.setSite(Directions.East, new Wall(Directions.East));
        r8.setSite(Directions.North, new Wall(Directions.North)); 
        r8.setSite(Directions.West, new Wall(Directions.West));

        Room r5 = new Room(x + 2*MapSite.Length, y, nr++);
        r5.setSite(Directions.South, new Wall(Directions.South)); 
        r5.setSite(Directions.East, new Wall(Directions.East));
        r5.setSite(Directions.North, new Wall(Directions.North)); 
        r5.setSite(Directions.West, new Wall(Directions.West));

        Room r6 = new Room(x + 3*MapSite.Length, y, nr++);
        r6.setSite(Directions.South, new Wall(Directions.South)); 
        r6.setSite(Directions.East, new Wall(Directions.East));
        r6.setSite(Directions.North, new Wall(Directions.North)); 
        r6.setSite(Directions.West, new Wall(Directions.West));

        Room r9 = new Room(x + 4*MapSite.Length, y, nr++);
        r9.setSite(Directions.South, new Wall(Directions.South)); 
        r9.setSite(Directions.East, new Wall(Directions.East));
        r9.setSite(Directions.North, new Wall(Directions.North)); 
        r9.setSite(Directions.West, new Wall(Directions.West));

        Room r4 = new Room(x + MapSite.Length, y - MapSite.Length, nr++);
        r4.setSite(Directions.South, new Wall(Directions.South)); 
        r4.setSite(Directions.East, new Wall(Directions.East));
        r4.setSite(Directions.North, new Wall(Directions.North)); 
        r4.setSite(Directions.West, new Wall(Directions.West));

        Room r7 = new Room(x + 3*MapSite.Length, y - MapSite.Length, nr++);
        r7.setSite(Directions.South, new Wall(Directions.South)); 
        r7.setSite(Directions.East, new Wall(Directions.East));
        r7.setSite(Directions.North, new Wall(Directions.North)); 
        r7.setSite(Directions.West, new Wall(Directions.West));

        Door d12 = new Door(r1, r2);
        Door d23 = new Door(r2, r3);
        Door d24 = new Door(r2, r4);
        Door d25 = new Door(r2, r5);
        Door d56 = new Door(r5, r6);
        Door d67 = new Door(r6, r7);
        Door d68 = new Door(r6, r8);
        Door d69 = new Door(r6, r9);

        r1.setSite(Directions.East, d12);
        r2.setSite(Directions.West, d12);

        r2.setSite(Directions.South, d23);
        r3.setSite(Directions.North, d23);

        r2.setSite(Directions.North, d24);
        r4.setSite(Directions.South, d24);

        r2.setSite(Directions.East, d25);
        r5.setSite(Directions.West, d25);

        r5.setSite(Directions.East, d56);
        r6.setSite(Directions.West, d56);

        r6.setSite(Directions.North, d67);
        r7.setSite(Directions.South, d67);

        r6.setSite(Directions.South, d68);
        r8.setSite(Directions.North, d68);

        r6.setSite(Directions.East, d69);
        r9.setSite(Directions.West, d69);

        r1.draw(image);
        r2.draw(image);
        r3.draw(image);
        r4.draw(image);
        r5.draw(image);
        r6.draw(image);
        r7.draw(image);
        r8.draw(image);
        r9.draw(image);
    }

    public static void main( String[] args )
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App();
            }
        });

    }
}

